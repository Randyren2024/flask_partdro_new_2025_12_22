import os
import json
import requests
import logging
from flask import Flask, request, Response, send_from_directory, render_template, session, redirect, url_for, flash
from flask_cors import CORS
from functools import wraps

# 配置日志
logging.basicConfig(
    filename='app_debug.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
# 同时输出到控制台
console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
logging.getLogger('').addHandler(console)

import dashscope
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__, 
            static_folder='static/chat',
            static_url_path='/static',
            template_folder='templates')
app.secret_key = os.getenv("SECRET_KEY", "default_secret_key")
CORS(app)

# --- 配置初始化 ---
BOT_TYPE = os.getenv("BOT_TYPE", "bailian")
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY")
BAILIAN_APP_ID = os.getenv("BAILIAN_APP_ID")
DIFY_API_KEY = os.getenv("DIFY_API_KEY")
DIFY_API_URL = os.getenv("DIFY_API_URL", "https://api.dify.ai/v1")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

# --- 管理后台逻辑 ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def update_env_file(data):
    """更新 .env 文件"""
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    with open(env_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    new_lines = []
    updated_keys = set()
    
    for line in lines:
        if '=' in line and not line.strip().startswith('#'):
            key = line.split('=')[0].strip()
            if key in data:
                new_lines.append(f"{key}={data[key]}\n")
                updated_keys.add(key)
                continue
        new_lines.append(line)
    
    # 添加原本不存在的 key
    for key, value in data.items():
        if key not in updated_keys:
            new_lines.append(f"{key}={value}\n")
            
    with open(env_path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form.get('password') == ADMIN_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        return render_template('login.html', error="密码错误")
    return render_template('login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('logged_in', None)
    return redirect(url_for('admin_login'))

def get_current_env_values():
    """从 .env 文件中读取当前值，而不是使用内存中的旧值"""
    values = {}
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                if '=' in line and not line.strip().startswith('#'):
                    key, val = line.split('=', 1)
                    values[key.strip()] = val.strip()
    
    # 补全缺失的 key (使用内存中的默认值)
    defaults = {
        "BOT_TYPE": BOT_TYPE,
        "PORT": os.getenv("PORT", "5001"),
        "DASHSCOPE_API_KEY": DASHSCOPE_API_KEY,
        "BAILIAN_APP_ID": BAILIAN_APP_ID,
        "DIFY_API_KEY": DIFY_API_KEY,
        "DIFY_API_URL": DIFY_API_URL,
        "SUPABASE_URL": SUPABASE_URL,
        "SUPABASE_KEY": SUPABASE_KEY,
        "ADMIN_PASSWORD": ADMIN_PASSWORD
    }
    for k, v in defaults.items():
        if k not in values:
            values[k] = v
    return values

@app.route('/admin')
@login_required
def admin_dashboard():
    # 实时读取 .env 文件内容，确保显示的是最新的配置
    env_data = get_current_env_values()
    return render_template('admin.html', env_data=env_data)

@app.route('/admin/save', methods=['POST'])
@login_required
def admin_save():
    new_config = {
        "BOT_TYPE": request.form.get('BOT_TYPE'),
        "PORT": request.form.get('PORT'),
        "DASHSCOPE_API_KEY": request.form.get('DASHSCOPE_API_KEY'),
        "BAILIAN_APP_ID": request.form.get('BAILIAN_APP_ID'),
        "DIFY_API_KEY": request.form.get('DIFY_API_KEY'),
        "DIFY_API_URL": request.form.get('DIFY_API_URL'),
        "SUPABASE_URL": request.form.get('SUPABASE_URL'),
        "SUPABASE_KEY": request.form.get('SUPABASE_KEY'),
        "ADMIN_PASSWORD": request.form.get('ADMIN_PASSWORD')
    }
    try:
        update_env_file(new_config)
        flash("配置已更新！请手动重启程序以使所有更改生效。", "success")
    except Exception as e:
        flash(f"保存失败: {str(e)}", "danger")
    return redirect(url_for('admin_dashboard'))

# 初始化 Supabase 客户端
supabase: Client = None

def get_supabase_client():
    """动态获取 Supabase 客户端，确保使用最新的配置"""
    global supabase
    current_env = get_current_env_values()
    url = current_env.get("SUPABASE_URL")
    key = current_env.get("SUPABASE_KEY")
    
    if url and key and not url.startswith("YOUR_"):
        try:
            return create_client(url, key)
        except Exception as e:
            print(f"Supabase initialization failed: {e}")
    return None

def log_to_supabase(session_id, role, content, engine=None):
    """统一记录对话到 Supabase"""
    client = get_supabase_client()
    if not client:
        logging.error("Supabase client not initialized. Skipping log.")
        return
    
    # 打印调试信息，确认收到的数据
    logging.debug(f"DEBUG Supabase: Logging {role} for session {session_id}")
    
    try:
        # 1. 确保 session 存在于 chat_sessions 表中
        try:
            # 检查 session 是否已存在
            existing_session = client.table("chat_sessions").select("id").eq("session_id", session_id).execute()
            if not existing_session.data:
                # 如果不存在，创建新 session
                logging.info(f"DEBUG Supabase: Creating new session {session_id}")
                client.table("chat_sessions").insert({"session_id": session_id}).execute()
        except Exception as sess_e:
            logging.error(f"Error ensuring session exists: {sess_e}")

        # 2. 插入对话消息到 chat_messages 表
        # chat_messages 表字段: session_id, role, content
        res = client.table("chat_messages").insert({
            "session_id": session_id,
            "role": role,
            "content": content
        }).execute()
        logging.info(f"DEBUG Supabase: Insert result: {res}")
        logging.info(f"Successfully logged {role} message to Supabase for session {session_id}")
        
    except Exception as e:
        logging.error(f"Error logging to Supabase: {e}")
        # 尝试打印更详细的错误信息
        import traceback
        logging.error(traceback.format_exc())

@app.route('/')
def serve_index():
    """渲染主页模板"""
    current_env = get_current_env_values()
    current_bot_type = current_env.get("BOT_TYPE", "bailian")
    print(f"DEBUG: Rendering index with bot_type={current_bot_type}")
    return render_template('index.html', bot_type=current_bot_type)

@app.route('/api/chat', methods=['POST'])
def chat():
    # 动态读取最新的 BOT_TYPE
    current_env = get_current_env_values()
    current_bot_type = current_env.get("BOT_TYPE", "bailian")
    
    data = request.json
    query = data.get('query')
    session_id = data.get('conversation_id', '')
    
    # 对于百炼，如果没有 session_id，生成一个 UUID 维持上下文
    if current_bot_type == "bailian" and not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    print(f"收到聊天请求: query='{query}', session_id='{session_id}', engine='{current_bot_type}'")

    # 1. 记录用户提问 (对于 Dify 新会话，稍后在 stream_dify 中获取到 ID 后再记录)
    if current_bot_type == "bailian" or session_id:
        log_to_supabase(session_id, "user", query, engine=current_bot_type)

    # 2. 根据当前引擎路由
    if current_bot_type == "bailian":
        print("使用百炼引擎...")
        return Response(stream_bailian(query, session_id), mimetype='text/event-stream')
    else:
        print("使用 Dify 引擎...")
        return Response(stream_dify(query, session_id, current_env), mimetype='text/event-stream')

def stream_bailian(query, session_id):
    """百炼引擎流式处理"""
    current_env = get_current_env_values()
    api_key = current_env.get("DASHSCOPE_API_KEY")
    app_id = current_env.get("BAILIAN_APP_ID")
    
    try:
        print(f"正在调用百炼 API (AppID: {app_id})...")
        responses = dashscope.Application.call(
            app_id=app_id,
            api_key=api_key,
            prompt=query,
            session_id=session_id,
            stream=True
        )
        full_answer = ""
        yielded_answer = ""
        for response in responses:
            if response.status_code == 200:
                full_answer = response.output.text
                delta = full_answer[len(yielded_answer):]
                yielded_answer = full_answer
                # 增加 conversation_id 以便前端记录会话状态
                yield f"data: {json.dumps({'event': 'message', 'answer': delta, 'conversation_id': session_id})}\n\n"
            else:
                print(f"百炼 API 错误: {response.message}")
                yield f"data: {json.dumps({'event': 'error', 'message': response.message})}\n\n"
                break
        
        log_to_supabase(session_id, "assistant", full_answer, engine="bailian")
        yield "data: [DONE]\n\n"
    except Exception as e:
        print(f"百炼处理异常: {str(e)}")
        yield f"data: {json.dumps({'event': 'error', 'message': str(e)})}\n\n"

def stream_dify(query, session_id, current_env=None):
    """Dify 引擎流式处理"""
    if not current_env:
        current_env = get_current_env_values()
        
    api_key = current_env.get("DIFY_API_KEY")
    api_url = current_env.get("DIFY_API_URL", "https://api.dify.ai/v1")
    
    # 追踪当前的会话 ID
    current_session_id = session_id
    # 标记用户消息是否已记录
    user_msg_logged = True if session_id else False
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        payload = {
            "inputs": {},
            "query": query,
            "user": "flask-user",
            "response_mode": "streaming",
            "conversation_id": session_id or ""
        }
        
        # 修复 URL 拼接，防止双斜杠问题
        base_url = api_url.rstrip('/')
        target_url = f"{base_url}/chat-messages"
        print(f"正在调用 Dify API: {target_url}")
        
        # 显式禁用代理以避免 malformed proxy 错误，并增加超时
        r = requests.post(
            target_url,
            headers=headers,
            json=payload,
            stream=True,
            proxies={"http": None, "https": None},
            timeout=10
        )
        print(f"Dify 响应状态码: {r.status_code}")
        
        if r.status_code != 200:
            error_msg = f"Dify API 返回错误: {r.status_code}"
            try:
                error_detail = r.json()
                error_msg += f" - {error_detail.get('message', '')}"
            except:
                pass
            print(error_msg)
            yield f"data: {json.dumps({'event': 'error', 'message': error_msg})}\n\n"
            return

        full_answer = ""
        try:
            for line in r.iter_lines():
                if line:
                    decoded_line = line.decode('utf-8')
                    # 记录每一行原始数据，无论是否以 data: 开头
                    logging.info(f"RAW Dify Line: {decoded_line}")
                    
                    if decoded_line.startswith('data:'):
                        yield f"{decoded_line}\n\n"
                        try:
                            data_str = decoded_line[5:].strip()
                            if data_str == "[DONE]":
                                break
                            data = json.loads(data_str)
                            
                            # 打印每一帧数据，用于调试
                            logging.debug(f"DEBUG Dify Stream Frame: {data}")

                            # 尝试获取 conversation_id
                            # 修复：Dify 的 conversation_id 有时在 message 事件中才返回
                            c_id = data.get('conversation_id')
                            
                            if c_id and not current_session_id:
                                current_session_id = c_id
                                # 如果之前因为没有 session_id 而没记录用户消息，现在补录
                                if not user_msg_logged:
                                    logging.info(f"Dify 新会话 ID 获取成功: {current_session_id}，正在补录用户消息...")
                                    # 确保 session 在 Supabase 中存在
                                    try:
                                        client = get_supabase_client()
                                        if client:
                                            # 强制先插入 session，防止并发问题
                                            logging.info(f"DEBUG Supabase: Pre-creating session {current_session_id} for user log")
                                            client.table("chat_sessions").upsert({"session_id": current_session_id}, on_conflict="session_id").execute()
                                    except Exception as e:
                                        logging.error(f"Error pre-creating session: {e}")

                                    log_to_supabase(current_session_id, "user", query, engine="dify")
                                    user_msg_logged = True
                            
                            # 修复：确保所有类型的消息都被正确拼接
                            if data.get('event') in ['message', 'agent_message', 'text_chunk']:
                                answer_chunk = data.get('answer', '')
                                # 有些版本的 Dify 返回的是 'text' 字段而不是 'answer'
                                if not answer_chunk and 'text' in data:
                                    answer_chunk = data.get('text', '')
                                full_answer += answer_chunk
                        except:
                            pass
        finally:
            # 使用最终确认的 session_id 记录助手回复
            # 无论流是否正常结束（包括用户断开连接），都会执行此块
            if current_session_id and full_answer:
                logging.info(f"Stream finished/closed. Logging assistant message for session {current_session_id}")
                log_to_supabase(current_session_id, "assistant", full_answer, engine="dify")
            else:
                logging.warning(f"Stream ended without logging. Session: {current_session_id}, Answer Len: {len(full_answer)}")
            
    except requests.exceptions.Timeout:
        logging.error("Dify API 请求超时")
        yield f"data: {json.dumps({'event': 'error', 'message': 'Dify API 请求超时，请检查网络连接'})}\n\n"
    except Exception as e:
        print(f"Dify 处理异常: {str(e)}")
        yield f"data: {json.dumps({'event': 'error', 'message': str(e)})}\n\n"

@app.route('/analysis/trigger', methods=['POST'])
def analysis_trigger():
    """处理离场分析触发"""
    data = request.json
    session_id = data.get('session_id')
    print(f"Analysis triggered for session: {session_id}")
    # 这里可以添加更复杂的分析逻辑，比如统计时长等
    return {"status": "success"}

if __name__ == '__main__':
    port = int(os.getenv("PORT", 5001))
    print(f"Server starting on port {port} with engine: {BOT_TYPE}")
    app.run(host='0.0.0.0', port=port, debug=False)
