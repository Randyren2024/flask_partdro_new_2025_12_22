/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // ShadCN / Taobao Style (Warm/Professional)
        primary: {
          DEFAULT: "#ff5000", // 淘宝橙
          foreground: "#ffffff",
        },
        background: "#ffffff",
        foreground: "#333333",
        muted: {
          DEFAULT: "#f4f4f5",
          foreground: "#71717a",
        },
        accent: {
          DEFAULT: "#fff1eb", // 浅暖橙色背景
          foreground: "#ff5000",
        },
        border: "#e4e4e7",
        deepNavy: "#001a4d", // Keep for legacy if needed
        cyberCyan: "#00f2ff",
      },
      boxShadow: {
        soft: "0 2px 12px 0 rgba(0,0,0,0.1)",
      },
      backgroundImage: {
        'taobao-gradient': "linear-gradient(135deg, #ff9000 0%, #ff5000 100%)",
      },
    },
  },
  plugins: [],
}
