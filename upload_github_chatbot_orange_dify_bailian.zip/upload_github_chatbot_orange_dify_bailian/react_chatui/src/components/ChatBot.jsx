import React, { useState, useEffect, useRef } from 'react';
import { X, Bot, Zap, MessageCircle } from 'lucide-react';
import ChatMessage from './chat/ChatMessage';
import ChatInput from './chat/ChatInput';
import { cn } from '../lib/utils';

const ChatBot = ({ onClose }) => {
  const [messages, setMessages] = useState([]);
  const [sessionId, setSessionId] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);
  const hasWelcomed = useRef(false);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Initial Welcome Message
  useEffect(() => {
    if (!hasWelcomed.current) {
      setMessages([
        {
          id: 'welcome',
          type: 'text',
          content: { text: 'Hello! I am your Partdro Drone Guide. How can I help you today?' },
          position: 'left',
        },
        {
          id: 'whatsapp',
          type: 'text',
          content: { text: 'whatsapp_action' },
          position: 'left',
        }
      ]);
      hasWelcomed.current = true;
    }
  }, []);

  const handleSend = async (type, val) => {
    if (type === 'text' && val.trim()) {
      // 1. Append User Message
      const userMsg = {
        id: Date.now().toString(),
        type: 'text',
        content: { text: val },
        position: 'right',
      };
      setMessages(prev => [...prev, userMsg]);

      setIsTyping(true);

      // 2. Prepare AI Placeholder
      const messageId = (Date.now() + 1).toString();
      const thinkingMsg = {
        id: messageId,
        type: 'text',
        content: { text: 'thinking' },
        position: 'left',
      };
      setMessages(prev => [...prev, thinkingMsg]);

      try {
        const API_URL = `/api/chat`; 

        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            query: val,
            conversation_id: sessionId || ''
          }),
        });

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let aiText = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data:')) {
              const dataStr = line.replace('data:', '').trim();
              if (!dataStr) continue;

              try {
                if (dataStr === '[DONE]') break;
                console.log('Dify data chunk:', dataStr);
                const data = JSON.parse(dataStr);
                
                // Capture conversation ID to maintain session
                if (data.conversation_id && !sessionId) {
                  setSessionId(data.conversation_id);
                }

                // Dify streaming event handling
                if (data.event === 'message' || data.event === 'agent_message') {
                  const chunk = data.answer || '';
                  aiText += chunk;
                  
                  setMessages(prev => prev.map(msg => 
                    msg.id === messageId 
                      ? { ...msg, content: { text: aiText } } 
                      : msg
                  ));
                }
                
                if (data.event === 'message_end') break;
              } catch (e) {
                console.error('JSON parse error', e);
              }
            }
          }
        }
      } catch (err) {
        console.error('Chat Error:', err);
        setMessages(prev => prev.map(msg => 
          msg.id === messageId 
            ? { ...msg, content: { text: 'Sorry, I encountered an error connecting to the server.' } } 
            : msg
        ));
      } finally {
        setIsTyping(false);
      }
    }
  };

  const handleClose = () => {
    if (sessionId) {
      const triggerUrl = `/analysis/trigger`;
      
      const payload = JSON.stringify({ session_id: sessionId });
      try {
        navigator.sendBeacon(triggerUrl, payload);
      } catch (e) {
        fetch(triggerUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload,
          keepalive: true
        }).catch(err => console.error('Analysis trigger failed:', err));
      }
    }
    onClose();
  };

  return (
    <div id="partdro-chat-widget" className="flex flex-col h-full bg-white overflow-hidden shadow-soft border border-border">
      {/* Modern Header - Taobao/Warm Style */}
      <div className="relative px-5 py-4 bg-taobao-gradient flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <Bot size={22} className="text-white" />
            </div>
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <div className="text-white font-bold text-sm tracking-wider flex items-center gap-1.5">
              智能助理
              <Zap size={12} className="text-yellow-300 fill-yellow-300" />
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-white/80 font-medium">
              <span>在线中</span>
              <span className="w-1 h-1 rounded-full bg-white/50 animate-ping"></span>
            </div>
          </div>
        </div>
        <button 
          onClick={handleClose}
          className="p-2 rounded-lg bg-white/10 text-white/80 hover:text-white hover:bg-white/20 transition-all active:scale-95"
        >
          <X size={20} />
        </button>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 py-6 space-y-4 bg-gray-50/50"
        style={{ scrollBehavior: 'smooth' }}
      >
        {messages.map((msg) => (
          <ChatMessage key={msg.id} message={msg} />
        ))}
        {isTyping && (
           <div className="flex items-center gap-2 text-[10px] text-primary font-bold tracking-tighter px-2">
             <div className="animate-bounce">●</div>
             <div className="animate-bounce delay-75">●</div>
             <div className="animate-bounce delay-150">●</div>
             正在思考...
           </div>
        )}
      </div>

      {/* Input Area */}
      <ChatInput onSend={handleSend} disabled={isTyping} />
    </div>
  );
};

export default ChatBot;
