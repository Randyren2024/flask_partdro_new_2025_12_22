import React, { useState } from 'react';
import { Send, Zap } from 'lucide-react';
import { cn } from '../../lib/utils';

const ChatInput = ({ onSend, disabled }) => {
  const [value, setValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim() && !disabled) {
      onSend('text', value);
      setValue('');
    }
  };

  return (
    <div className="p-4 bg-white border-t border-border">
      <form 
        onSubmit={handleSubmit}
        className="relative flex items-center group"
      >
        <div className="absolute left-3 text-primary/50 group-focus-within:text-primary transition-colors">
          <Zap size={16} />
        </div>
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          disabled={disabled}
          placeholder="请输入您的问题..."
          className={cn(
            "w-full bg-muted border border-border rounded-xl py-3 pl-10 pr-12 text-sm text-foreground placeholder:text-muted-foreground outline-none transition-all",
            "focus:border-primary/50 focus:bg-white focus:ring-1 focus:ring-primary/20",
            disabled && "opacity-50 cursor-not-allowed"
          )}
        />
        <button
          type="submit"
          disabled={!value.trim() || disabled}
          className={cn(
            "absolute right-2 p-2 rounded-lg transition-all",
            value.trim() && !disabled 
              ? "bg-taobao-gradient text-white shadow-soft scale-100 hover:scale-105" 
              : "bg-muted text-muted-foreground scale-95"
          )}
        >
          <Send size={18} />
        </button>
      </form>
      <div className="mt-2 text-[10px] text-center text-muted-foreground uppercase tracking-widest">
        智能助理 • v2.0
      </div>
    </div>
  );
};

export default ChatInput;
