import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Bot, User } from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion } from 'framer-motion';

const WhatsAppIcon = ({ className }) => (
  <svg 
    viewBox="0 0 24 24" 
    className={cn("fill-[#25D366]", className)} 
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
);

const ChatMessage = ({ message }) => {
  const isAi = message.position === 'left';
  const isWhatsApp = message.content.text === 'whatsapp_action';
  const isThinking = message.content.text === 'thinking';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.2 }}
      className={cn(
        "flex w-full mb-4 gap-3",
        isAi ? "justify-start" : "justify-end"
      )}
    >
      {isAi && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-taobao-gradient flex items-center justify-center shadow-soft">
          <Bot size={18} className="text-white" />
        </div>
      )}
      
      <div className={cn(
        "max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed transition-all duration-300",
        isAi 
          ? "bg-white border border-border text-foreground rounded-tl-none shadow-soft" 
          : "bg-taobao-gradient text-white font-medium rounded-tr-none shadow-soft"
      )}>
        {isWhatsApp ? (
          <a 
            href="https://wa.me/8613362853598" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-3 hover:opacity-80 transition-opacity py-1.5 group"
          >
            <motion.div
              animate={{ y: [0, -4, 0] }}
              transition={{ 
                duration: 2, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            >
              <WhatsAppIcon className="w-6 h-6 drop-shadow-[0_0_5px_rgba(37,211,102,0.5)]" />
            </motion.div>
            <span className="font-bold text-[#25D366] underline decoration-2 underline-offset-4 group-hover:no-underline transition-all">
              Chat on WhatsApp
            </span>
          </a>
        ) : isThinking ? (
          <div className="flex items-center gap-1.5 py-1">
            <span className="text-xs uppercase tracking-widest text-primary font-bold animate-pulse">Thinking</span>
            <div className="flex gap-1">
              <motion.span 
                animate={{ scale: [1, 1.2, 1], opacity: [0.3, 1, 0.3] }}
                transition={{ repeat: Infinity, duration: 1.4, delay: 0 }}
                className="w-1.5 h-1.5 rounded-full bg-primary" 
              />
              <motion.span 
                animate={{ scale: [1, 1.2, 1], opacity: [0.3, 1, 0.3] }}
                transition={{ repeat: Infinity, duration: 1.4, delay: 0.2 }}
                className="w-1.5 h-1.5 rounded-full bg-primary" 
              />
              <motion.span 
                animate={{ scale: [1, 1.2, 1], opacity: [0.3, 1, 0.3] }}
                transition={{ repeat: Infinity, duration: 1.4, delay: 0.4 }}
                className="w-1.5 h-1.5 rounded-full bg-primary" 
              />
            </div>
          </div>
        ) : (
          <div className={cn(
            "prose max-w-none break-words",
            isAi ? "prose-p:text-foreground" : "text-white prose-p:my-0 prose-headings:text-white prose-p:text-white"
          )}>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {message.content.text}
            </ReactMarkdown>
          </div>
        )}
      </div>

      {!isAi && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center border border-white/10">
          <User size={18} className="text-white/70" />
        </div>
      )}
    </motion.div>
  );
};

export default ChatMessage;
