import React, { useState } from 'react';
import ChatBot from './components/ChatBot';
import { MessageCircle, X } from 'lucide-react';
import './widget.css';

function App() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="widget-container">
      {/* Chat Window */}
      <div className={`chat-window ${isOpen ? 'open' : 'closed'}`}>
        <ChatBot onClose={() => setIsOpen(false)} />
      </div>

      {/* Launcher Button */}
      <button 
        className="launcher-button"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Toggle Chat"
      >
        {isOpen ? (
          <X size={28} color="white" />
        ) : (
          <MessageCircle size={28} color="white" />
        )}
      </button>
    </div>
  );
}

export default App;
