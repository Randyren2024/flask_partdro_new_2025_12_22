import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    // Output to Flask static folder
    outDir: '../flask_backend/static/chat',
    emptyOutDir: true,
    rollupOptions: {
      output: {
        // Force fixed filenames
        entryFileNames: 'assets/widget.js',
        chunkFileNames: 'assets/widget-[name].js',
        assetFileNames: 'assets/widget.[ext]'
      }
    }
  },
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
        secure: false,
      }
    }
  }
})
