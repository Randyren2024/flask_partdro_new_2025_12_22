import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// 托管构建后的静态文件
app.use(express.static(path.join(__dirname, 'dist')));

// 所有路由指向 index.html，支持单页应用路由
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// 函数计算默认使用 9000 端口
const port = process.env.FC_SERVER_PORT || 9000;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
