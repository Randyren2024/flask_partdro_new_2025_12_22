#!/bin/bash

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}>>> 开始一键部署 Chatbot 整合系统 (轻量应用服务器版)...${NC}"

# 1. 检查环境
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}>>> 未检测到 Docker，正在安装...${NC}"
    curl -fsSL https://get.docker.com | bash -s docker
    systemctl start docker
    systemctl enable docker
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}>>> 未检测到 Docker Compose，正在安装...${NC}"
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# 2. 针对 1GB 内存的优化：检查 Swap
MEM_TOTAL=$(free -m | grep Mem | awk '{print $2}')
SWAP_TOTAL=$(free -m | grep Swap | awk '{print $2}')

if [ "$MEM_TOTAL" -lt 1500 ] && [ "$SWAP_TOTAL" -lt 512 ]; then
    echo -e "${YELLOW}>>> 检测到内存较小且无虚拟内存，正在创建 2GB Swap 以防构建失败...${NC}"
    fallocate -l 2G /swapfile
    chmod 600 /swapfile
    mkswap /swapfile
    swapon /swapfile
    echo '/swapfile none swap sw 0 0' >> /etc/fstab
    echo -e "${GREEN}>>> Swap 创建成功。${NC}"
fi

# 3. 停止并移除旧容器
echo -e "${GREEN}>>> 清理旧容器...${NC}"
docker-compose down

# 4. 构建并启动服务
echo -e "${GREEN}>>> 正在构建镜像并启动服务 (1GB内存服务器构建可能较慢，请耐心等待)...${NC}"
docker-compose up -d --build

if [ $? -eq 0 ]; then
    echo -e "${GREEN}>>> 部署成功！${NC}"
    echo -e "${GREEN}>>> 当前容器状态：${NC}"
    docker ps | grep orange-chatbot-backend
    echo -e "${GREEN}>>> 系统已在端口 5002 启动。${NC}"
    echo -e "${YELLOW}>>> 重要提示：请在阿里云轻量应用服务器控制台的“防火墙”页面开放 5002 端口。${NC}"
else
    echo -e "${RED}>>> 部署失败，请检查上方报错信息。${NC}"
fi
