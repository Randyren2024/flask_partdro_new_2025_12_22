import csv
import os
from supabase_client import supabase

# Try to import tqdm for progress bar, otherwise use a simple replacement
try:
    from tqdm import tqdm
except ImportError:
    class tqdm:
        def __init__(self, iterable, desc=""):
            self.iterable = iterable
            self.desc = desc
            self.total = len(iterable)
        def __iter__(self):
            for i, item in enumerate(self.iterable):
                if i % 10 == 0:
                    print(f"{self.desc}: {i}/{self.total}", end='\r')
                yield item
            print(f"{self.desc}: {self.total}/{self.total}")

import time

def import_embeddings(csv_file_path, batch_size=100, clear_table=False):
    if not os.path.exists(csv_file_path):
        print(f"Error: CSV file not found at {csv_file_path}")
        return

    if clear_table:
        print("Clearing existing data from 'search_term_embeddings'...")
        try:
            # Delete all rows (requires RLS to allow delete or service role key)
            supabase.table('search_term_embeddings').delete().neq('id', 0).execute()
            print("Table cleared.")
        except Exception as e:
            print(f"Warning: Could not clear table: {e}")

    print(f"Reading embeddings from {csv_file_path}...")
    
    data_to_insert = []
    
    with open(csv_file_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        
        # Get dimension columns (dim_0, dim_1, ...)
        dim_cols = [col for col in reader.fieldnames if col.startswith('dim_')]
        dim_cols.sort(key=lambda x: int(x.split('_')[1]))
        
        print(f"Detected {len(dim_cols)} dimensions.")
        
        # Read all rows
        rows = list(reader)
        total_rows = len(rows)
        print(f"Found {total_rows} rows to import.")
        
        for i, row in enumerate(tqdm(rows, desc="Processing rows")):
            search_term = row['search_term']
            # Extract embedding as a list of floats
            embedding = [float(row[col]) for col in dim_cols]
            
            data_to_insert.append({
                'search_term': search_term,
                'embedding': embedding
            })
            
            # Batch insert
            if len(data_to_insert) >= batch_size:
                retries = 3
                while retries > 0:
                    try:
                        supabase.table('search_term_embeddings').insert(data_to_insert).execute()
                        data_to_insert = []
                        break
                    except Exception as e:
                        retries -= 1
                        print(f"\nError inserting batch: {e}. Retrying ({3-retries}/3)...")
                        time.sleep(2)
                        if retries == 0:
                            print(f"Failed to insert batch after 3 retries. Skipping.")
                            data_to_insert = []

        # Insert remaining data
        if data_to_insert:
            retries = 3
            while retries > 0:
                try:
                    supabase.table('search_term_embeddings').insert(data_to_insert).execute()
                    break
                except Exception as e:
                    retries -= 1
                    print(f"\nError inserting final batch: {e}. Retrying ({3-retries}/3)...")
                    time.sleep(2)

    print("\nImport completed!")

if __name__ == "__main__":
    csv_path = r"supabase\embeddings\search_term_embeddings.csv"
    import_embeddings(csv_path, clear_table=True)
