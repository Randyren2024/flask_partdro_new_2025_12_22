import os
from flask import render_template, request, redirect, url_for, session, flash, current_app
from functools import wraps
from partdro.blueprints.admin import admin_bp

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('admin.admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def update_env_file(data):
    """更新 .env 文件"""
    env_path = os.path.join(current_app.root_path, '..', '.env')
    if not os.path.exists(env_path):
        return
        
    with open(env_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    new_lines = []
    updated_keys = set()
    
    for line in lines:
        if '=' in line and not line.strip().startswith('#'):
            key = line.split('=')[0].strip()
            if key in data:
                new_lines.append(f"{key}={data[key]}\n")
                updated_keys.add(key)
                continue
        new_lines.append(line)
    
    for key, value in data.items():
        if key not in updated_keys:
            new_lines.append(f"{key}={value}\n")
            
    with open(env_path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)

def get_current_env_values():
    """从 .env 文件中读取当前值"""
    values = {}
    env_path = os.path.join(current_app.root_path, '..', '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                if '=' in line and not line.strip().startswith('#'):
                    parts = line.split('=', 1)
                    if len(parts) == 2:
                        values[parts[0].strip()] = parts[1].strip()
    return values

@admin_bp.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    admin_password = os.getenv("ADMIN_PASSWORD", "admin123")
    if request.method == 'POST':
        if request.form.get('password') == admin_password:
            session['logged_in'] = True
            return redirect(url_for('admin.admin_dashboard'))
        return render_template('login.html', error="密码错误")
    return render_template('login.html')

@admin_bp.route('/admin/logout')
def admin_logout():
    session.pop('logged_in', None)
    return redirect(url_for('admin.admin_login'))

@admin_bp.route('/admin')
@login_required
def admin_dashboard():
    current_env = get_current_env_values()
    return render_template('admin.html', config=current_env)

@admin_bp.route('/admin/save_config', methods=['POST'])
@login_required
def save_config():
    new_config = {
        "BOT_TYPE": request.form.get("BOT_TYPE"),
        "PORT": request.form.get("PORT"),
        "DIFY_API_KEY": request.form.get("DIFY_API_KEY"),
        "DIFY_API_URL": request.form.get("DIFY_API_URL"),
        "BAILIAN_APP_ID": request.form.get("BAILIAN_APP_ID"),
        "DASHSCOPE_API_KEY": request.form.get("DASHSCOPE_API_KEY"),
        "SUPABASE_URL": request.form.get("SUPABASE_URL"),
        "SUPABASE_KEY": request.form.get("SUPABASE_KEY"),
        "ADMIN_PASSWORD": request.form.get("ADMIN_PASSWORD"),
    }
    try:
        update_env_file(new_config)
        flash("配置已更新！请手动重启程序以使所有更改生效。", "success")
    except Exception as e:
        flash(f"保存失败: {str(e)}", "danger")
    return redirect(url_for('admin.admin_dashboard'))
