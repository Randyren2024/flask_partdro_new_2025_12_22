import os
import json
import requests
import smtplib
import subprocess
import sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import request, jsonify, current_app, render_template
from partdro.auth import admin_required
from partdro.blueprints.analysis import analysis_bp
from partdro.extensions import supabase
from partdro.services.semantic import SemanticService

# --- AI Helper (DashScope) ---
def analyze_with_ai(messages):
    """
    Sends chat history to Aliyun DashScope (Qwen) for analysis.
    """
    api_key = os.getenv("DASHSCOPE_API_KEY") or "sk-31935adea80c4d03bd0709155f11b2c0"
    
    conversation_text = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
    
    prompt = f"""
    You are a professional sales assistant for a drone company.
    Analyze the following chat conversation and extract key information.
    
    Output a JSON object with the following fields:
    - "summary": A brief summary of the user's request.
    - "contact_info": {{ "name": "...", "phone": "...", "email": "...", "country": "..." }} (If found, otherwise null)
    - "intent": "Buying", "Support", "Inquiry", or "Other".
    - "sentiment": "Positive", "Neutral", "Negative".

    Conversation:
    {conversation_text}
    """

    try:
        response = requests.post(
            "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "qwen-turbo",
                "input": {
                    "messages": [
                        { "role": "system", "content": "You are a JSON extractor." },
                        { "role": "user", "content": prompt }
                    ]
                },
                "parameters": { "result_format": "message" }
            },
            timeout=30
        )
        
        if response.status_code != 200:
            print(f"AI API Error: {response.text}")
            return None
            
        data = response.json()
        content = data["output"]["choices"][0]["message"]["content"]
        
        # Clean markdown code blocks
        content = content.replace("```json", "").replace("```", "").strip()
        return json.loads(content)

    except Exception as e:
        print(f"AI Analysis Failed: {e}")
        return None

# --- Email Helper ---
def send_email_report(analysis, session_id):
    """
    Sends an email report via SMTP.
    """
    smtp_host = os.getenv("SMTP_HOSTNAME") or "smtp.exmail.qq.com"
    smtp_port = int(os.getenv("SMTP_PORT") or 465)
    smtp_user = os.getenv("SMTP_USER") or "info@partdro.com"
    smtp_pass = os.getenv("SMTP_PASSWORD")
    
    if not smtp_pass:
        print("SMTP Password not set, skipping email.")
        return False

    msg = MIMEMultipart()
    msg['From'] = f"Partdro AI <{smtp_user}>"
    msg['To'] = "info@partdro.com"
    msg['Subject'] = f"[Lead Detected] Chat Analysis: {session_id}"

    contact = analysis.get('contact_info') or {}
    
    html = f"""
    <h2>New Chat Analysis Report</h2>
    <p><strong>Session ID:</strong> {session_id}</p>
    <p><strong>Intent:</strong> {analysis.get('intent', 'N/A')}</p>
    <p><strong>Sentiment:</strong> {analysis.get('sentiment', 'N/A')}</p>
    
    <h3>Summary</h3>
    <p>{analysis.get('summary', 'No summary provided.')}</p>

    <h3>Extracted Contact Info</h3>
    <ul>
      <li><strong>Name:</strong> {contact.get('name', 'N/A')}</li>
      <li><strong>Phone:</strong> {contact.get('phone', 'N/A')}</li>
      <li><strong>Email:</strong> {contact.get('email', 'N/A')}</li>
      <li><strong>Country:</strong> {contact.get('country', 'N/A')}</li>
    </ul>
    
    <p><em>Powered by Partdro Flask AI</em></p>
    """
    
    msg.attach(MIMEText(html, 'html'))

    try:
        with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
            server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Email Failed: {e}")
        return False

# --- Route ---
# @analysis_bp.before_request
# def restrict_access():
#     admin_required()

@analysis_bp.route('/dashboard')
def dashboard():
    """
    Renders the Admin Analysis Dashboard.
    """
    return render_template('admin_dashboard.html')

@analysis_bp.route('/semantic')
def semantic_dashboard():
    """
    Renders the Semantic Analysis Dashboard.
    """
    return render_template('semantic_dashboard.html')

@analysis_bp.route('/market-intelligence')
def market_intelligence():
    """
    Renders the Market Intelligence & Product Matching Dashboard.
    """
    return render_template('market_intelligence.html')

@analysis_bp.route('/api/market/matching', methods=['GET'])
def get_market_matching():
    """
    API endpoint for Market Intelligence matching data.
    """
    service = SemanticService()
    result = service.get_market_matching_data()
    return jsonify(result)

@analysis_bp.route('/api/market/ai-insights', methods=['GET'])
def get_market_ai_insights():
    """
    API endpoint for AI-driven market insights.
    """
    service = SemanticService()
    result = service.get_ai_insights()
    return jsonify(result)

@analysis_bp.route('/api/semantic/clusters', methods=['GET'])
def get_semantic_clusters():
    """
    API endpoint for semantic clustering data.
    """
    source = request.args.get('source', default='search_terms')
    n_clusters = request.args.get('n_clusters', default=5, type=int)
    service = SemanticService()
    results = service.analyze_semantic_clusters(source_key=source, n_clusters=n_clusters)
    if results:
        return jsonify({"success": True, "data": results})
    return jsonify({"success": False, "error": "Failed to analyze clusters or not enough data"}), 200

@analysis_bp.route('/sessions', methods=['GET'])
def list_sessions():
    """
    List the latest chat sessions.
    """
    try:
        # Fetch latest sessions from Supabase
        res = supabase.table("chat_sessions").select("*").order("created_at", desc=True).limit(20).execute()
        return jsonify({"success": True, "sessions": res.data})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@analysis_bp.route('/get/<session_id>', methods=['GET'])
def get_analysis(session_id):
    """
    Fetch existing analysis for a session.
    """
    try:
        res = supabase.table("chat_analysis").select("*").eq("session_id", session_id).order("created_at", desc=True).limit(1).execute()
        if res.data:
            return jsonify({"success": True, "analysis": res.data[0]})
        else:
            return jsonify({"success": False, "error": "No analysis found"}), 404
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@analysis_bp.route('/api/sync-embeddings', methods=['POST'])
def sync_embeddings():
    """
    Triggers the sync_embeddings.py script to update Supabase vectors.
    """
    try:
        python_exe = sys.executable
        # Locate the script in the project root
        # Current file is at project_root/partdro/blueprints/analysis/routes.py
        # sync_embeddings.py is at project_root/sync_embeddings.py
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
        script_path = os.path.join(base_dir, "sync_embeddings.py")
        
        if not os.path.exists(script_path):
            return jsonify({
                "success": False, 
                "error": f"找不到同步脚本，请检查路径: {script_path}"
            }), 404

        # Run as a subprocess
        process = subprocess.run([python_exe, script_path], capture_output=True, text=True, timeout=120)
        
        if process.returncode == 0:
            return jsonify({
                "success": True, 
                "message": "同步完成", 
                "output": process.stdout
            })
        else:
            return jsonify({
                "success": False, 
                "error": process.stderr or "未知错误"
            }), 500
            
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "同步超时，请稍后重试"}), 504
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@analysis_bp.route('/trigger', methods=['POST'])
def trigger_analysis():
    data = request.json
    session_id = data.get('session_id')
    
    if not session_id:
        return jsonify({"error": "Missing session_id"}), 400

    # 1. Fetch Chat History
    try:
        res = supabase.table("chat_messages").select("*").eq("session_id", session_id).order("created_at", desc=False).execute()
        messages = res.data
        if not messages:
            return jsonify({"error": "No messages found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # 2. Analyze
    analysis = analyze_with_ai(messages)
    if not analysis:
        return jsonify({"error": "AI Analysis failed"}), 500

    # 3. Save Results
    contact = analysis.get("contact_info")
    
    # A. Save Contact (if valid)
    if contact and (contact.get("name") or contact.get("phone") or contact.get("email")):
        try:
            supabase.table("chat_contacts").insert({
                "session_id": session_id,
                "name": contact.get("name"),
                "phone": contact.get("phone"),
                "email": contact.get("email"),
                "country": contact.get("country")
            }).execute()
        except Exception as e:
            print(f"Contact Insert Error: {e}")

    # B. Save Full Analysis
    try:
        supabase.table("chat_analysis").insert({
            "session_id": session_id,
            "intent": analysis.get("intent"),
            "sentiment": analysis.get("sentiment"),
            "summary": analysis.get("summary"),
            "contact_info": contact,
            "raw_analysis": analysis
        }).execute()
    except Exception as e:
        print(f"Analysis Insert Error: {e}")

    # 4. Email
    email_sent = send_email_report(analysis, session_id)

    return jsonify({
        "success": True, 
        "analysis": analysis,
        "email_sent": email_sent
    })
