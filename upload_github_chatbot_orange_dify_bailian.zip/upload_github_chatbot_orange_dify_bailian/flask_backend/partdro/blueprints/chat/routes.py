import os
import json
import requests
import dashscope
from flask import request, Response, jsonify, current_app
from partdro.blueprints.chat import chat_bp
import partdro.extensions as ext
from flask_babel import gettext as _

def log_to_supabase(session_id, role, content, engine=None):
    """统一记录对话到 Supabase"""
    if not ext.supabase:
        # 尝试在首次使用时初始化，避免 import 时绑定值为 None
        try:
            from partdro.extensions import init_supabase
            init_supabase(current_app)
        except Exception as e:
            print(f"Supabase init failed: {e}")
        if not ext.supabase:
            print("Supabase client not initialized. Skipping log.")
            return
    
    try:
        # 1. 确保 session 存在
        try:
            existing_session = ext.supabase.table("chat_sessions").select("id").eq("session_id", session_id).execute()
            if not existing_session.data:
                ext.supabase.table("chat_sessions").insert({"session_id": session_id}).execute()
        except Exception as sess_e:
            print(f"Error ensuring session exists: {sess_e}")

        # 2. 插入消息
        ext.supabase.table("chat_messages").insert({
            "session_id": session_id,
            "role": role,
            "content": content
        }).execute()
    except Exception as e:
        print(f"Error logging to Supabase: {e}")

def stream_bailian(query, session_id):
    """百炼引擎流式处理"""
    api_key = os.getenv("DASHSCOPE_API_KEY")
    app_id = os.getenv("BAILIAN_APP_ID")
    
    try:
        responses = dashscope.Application.call(
            app_id=app_id,
            api_key=api_key,
            prompt=query,
            session_id=session_id,
            stream=True
        )
        full_answer = ""
        yielded_answer = ""
        for response in responses:
            if response.status_code == 200:
                full_answer = response.output.text
                delta = full_answer[len(yielded_answer):]
                yielded_answer = full_answer
                yield f"data: {json.dumps({'event': 'message', 'answer': delta, 'conversation_id': session_id})}\n\n"
            else:
                yield f"data: {json.dumps({'event': 'error', 'message': response.message})}\n\n"
                break
        
        log_to_supabase(session_id, "assistant", full_answer, engine="bailian")
        yield "data: [DONE]\n\n"
    except Exception as e:
        yield f"data: {json.dumps({'event': 'error', 'message': str(e)})}\n\n"

def stream_dify(query, session_id):
    """Dify 引擎流式处理"""
    api_key = os.getenv("DIFY_API_KEY")
    api_url = os.getenv("DIFY_API_URL", "https://api.dify.ai/v1")
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        payload = {
            "inputs": {},
            "query": query,
            "user": "flask-user",
            "response_mode": "streaming",
            "conversation_id": session_id or ""
        }
        
        base_url = api_url.rstrip('/')
        target_url = f"{base_url}/chat-messages"
        
        r = requests.post(
            target_url,
            headers=headers,
            json=payload,
            stream=True,
            proxies={"http": None, "https": None},
            timeout=10
        )
        
        if r.status_code != 200:
            error_msg = f"Dify API 返回错误: {r.status_code}"
            yield f"data: {json.dumps({'event': 'error', 'message': error_msg})}\n\n"
            return

        full_answer = ""
        for line in r.iter_lines():
            if line:
                decoded_line = line.decode('utf-8')
                if decoded_line.startswith('data:'):
                    yield f"{decoded_line}\n\n"
                    try:
                        data_str = decoded_line[5:].strip()
                        if data_str == "[DONE]":
                            break
                        data = json.loads(data_str)
                        if data.get('event') in ['message', 'agent_message']:
                            full_answer += data.get('answer', '')
                    except:
                        pass
        
        log_to_supabase(session_id, "assistant", full_answer, engine="dify")
    except Exception as e:
        yield f"data: {json.dumps({'event': 'error', 'message': str(e)})}\n\n"

@chat_bp.route('/api/chat', methods=['POST'])
def chat():
    bot_type = os.getenv("BOT_TYPE", "bailian")
    data = request.json
    query = data.get('query')
    session_id = data.get('conversation_id', '')
    
    if bot_type == "bailian" and not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    log_to_supabase(session_id, "user", query, engine=bot_type)

    if bot_type == "bailian":
        return Response(stream_bailian(query, session_id), mimetype='text/event-stream')
    else:
        return Response(stream_dify(query, session_id), mimetype='text/event-stream')
