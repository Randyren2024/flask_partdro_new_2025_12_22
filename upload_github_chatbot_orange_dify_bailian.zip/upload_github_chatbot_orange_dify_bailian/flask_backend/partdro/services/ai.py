import json
import httpx
from config import Config

def translate_product_info(name: str, description: str) -> dict:
    """
    Calls DeepSeek API to translate product name and description into
    Japanese (ja) and Spanish (es).
    Returns a dict with keys: name_ja, name_es, description_ja, description_es
    """
    if not Config.DEEPSEEK_API_KEY:
        raise ValueError("DEEPSEEK_API_KEY is not configured")

    # Prompt engineering: request JSON output
    prompt = f"""
You are a professional translator for technical drone products.
Translate the following product information into Japanese (ja) and Spanish (es).
Output ONLY a valid JSON object with these exact keys: "name_ja", "name_es", "description_ja", "description_es".
Do not include markdown formatting or extra text.

Product Name: {name}
Product Description: {description}
"""

    url = "https://api.deepseek.com/v1/chat/completions"  # Adjust if needed based on DeepSeek docs
    # Note: Using OpenAI-compatible endpoint structure common for DeepSeek
    
    # If the official endpoint differs, we might need to adjust. 
    # Assuming standard OpenAI compatibility for now:
    # Base URL often: https://api.deepseek.com or similar. 
    # Let's use the generic completion structure.
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {Config.DEEPSEEK_API_KEY}"
    }
    
    payload = {
        "model": "deepseek-chat",  # or deepseek-coder, deepseek-v3 etc.
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that outputs JSON."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3
    }

    try:
        # Using httpx for async-capable sync request or just standard sync
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            
            content = data["choices"][0]["message"]["content"]
            # Clean potential markdown code blocks if any
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            
            return json.loads(content.strip())
            
    except Exception as e:
        # Fallback or re-raise
        raise RuntimeError(f"Translation failed: {str(e)}")

def convert_md_to_html(content: str, provider: str = "deepseek", api_key: str = None, style_context: str = None) -> str:
    """
    Converts Markdown to HTML using the specified AI provider.
    Providers: 'deepseek' (default), 'gemini', 'qwen'.
    style_context: Optional CSS or style description to guide the generation.
    """
    base_prompt = (
        "You are a specialized web developer working on a Flask project. "
        "Convert the following Markdown content into clean, semantic HTML5 code. "
        "CONTEXT: The project uses Jinja2 templates and a Cyber/Tech theme. "
        "STYLE GUIDE: Use a Deep Navy background (#050505) and Cyan accents (#00f2ff). "
        "Fonts: 'Orbitron' for headers, 'Inter' for body. "
        "INSTRUCTIONS: Return ONLY the HTML code structure (no <html>/<body> tags). "
        "Use inline styles or Tailwind classes compatible with the reference theme."
    )

    if style_context:
        base_prompt += f"\n\nREFERENCE CSS/STYLES:\n{style_context}"

    system_prompt = base_prompt
    
    if provider == "deepseek":
        if not Config.DEEPSEEK_API_KEY:
            raise ValueError("DEEPSEEK_API_KEY is not configured")
        
        url = "https://api.deepseek.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {Config.DEEPSEEK_API_KEY}"
        }
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": content}
            ],
            "temperature": 0.3
        }
        
    elif provider == "gemini":
        if not api_key:
            raise ValueError("API Key is required for Gemini")
            
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}"
        headers = {"Content-Type": "application/json"}
        payload = {
            "contents": [{"parts": [{"text": f"{system_prompt}\n\nMARKDOWN CONTENT:\n{content}"}]}]
        }
        
    elif provider == "qwen":
        if not api_key:
            raise ValueError("API Key is required for Qwen")
            
        url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        payload = {
            "model": "qwen-turbo",
            "input": {
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": content}
                ]
            }
        }
        
    else:
        raise ValueError(f"Unknown provider: {provider}")

    try:
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            
            result_html = ""
            
            if provider == "deepseek":
                result_html = data["choices"][0]["message"]["content"]
            elif provider == "gemini":
                try:
                    result_html = data["candidates"][0]["content"]["parts"][0]["text"]
                except:
                    result_html = f"Error parsing Gemini response: {json.dumps(data)}"
            elif provider == "qwen":
                try:
                    result_html = data["output"]["text"]
                except:
                    result_html = f"Error parsing Qwen response: {json.dumps(data)}"
            
            # Clean markdown code blocks
            if result_html.startswith("```html"):
                result_html = result_html[7:]
            elif result_html.startswith("```"):
                result_html = result_html[3:]
            if result_html.endswith("```"):
                result_html = result_html[:-3]
                
            return result_html.strip()
            
    except Exception as e:
        raise RuntimeError(f"AI Conversion failed ({provider}): {str(e)}")
