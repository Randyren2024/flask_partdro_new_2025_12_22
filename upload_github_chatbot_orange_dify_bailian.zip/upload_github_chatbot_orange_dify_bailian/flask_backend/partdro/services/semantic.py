import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from partdro import extensions

class SemanticService:
    def __init__(self):
        from partdro.extensions import supabase
        self.supabase = supabase
        self.config_map = {
            'search_terms': {
                'table': 'search_term_embeddings',
                'text_col': 'search_term'
            },
            'chat_contacts': {
                'table': 'chat_contacts',
                'text_col': 'name'
            },
            'chat_analysis': {
                'table': 'chat_analysis',
                'text_col': 'summary'
            },
            'chat_messages': {
                'table': 'chat_messages',
                'text_col': 'content'
            },
            'partner_applications': {
                'table': 'partner_applications',
                'text_col': 'name'
            },
            'product': {
                'table': 'product',
                'text_col': 'name'
            },
            'google_ads_terms': {
                'table': 'search_term_embeddings',
                'text_col': 'search_term'
            }
        }

    @staticmethod
    def get_embeddings_from_table(table_name, text_column, embedding_column='embedding'):
        """Fetch text and embeddings from a specific table using pagination."""
        try:
            from partdro.extensions import supabase
            if not supabase:
                print("Error: Supabase client not initialized")
                return []
            
            all_data = []
            page_size = 1000
            offset = 0
            
            while True:
                response = supabase.table(table_name) \
                    .select(f'{text_column}, {embedding_column}') \
                    .not_.is_(embedding_column, 'null') \
                    .range(offset, offset + page_size - 1) \
                    .execute()
                
                batch = response.data
                if not batch:
                    break
                
                all_data.extend(batch)
                if len(batch) < page_size:
                    break
                
                offset += page_size
                
            return all_data
        except Exception as e:
            print(f"Error fetching embeddings from {table_name}: {e}")
            return []

    def _parse_embedding(self, emb):
        """Helper to parse embedding from string or list format."""
        if isinstance(emb, str):
            import json
            # Handle postgres vector format {1,2,3} -> [1,2,3]
            clean_emb = emb.replace('{', '[').replace('}', ']')
            try:
                return json.loads(clean_emb)
            except Exception as e:
                print(f"Error parsing embedding string: {e}")
                return None
        return emb

    def get_market_matching_data(self):
        """
        Retrieves matching data for Market Intelligence: Products vs Search Terms.
        """
        try:
            # 1. Get Product Embeddings
            prod_config = self.config_map['product']
            prod_res = self.supabase.table(prod_config['table']).select(f"id, {prod_config['text_col']}, embedding").not_.is_('embedding', 'null').execute()
            
            # 2. Get Search Term Embeddings (Google Ads Terms)
            ads_config = self.config_map['google_ads_terms']
            ads_res = self.supabase.table(ads_config['table']).select(f"id, {ads_config['text_col']}, embedding").not_.is_('embedding', 'null').execute()
            
            prod_data = prod_res.data
            ads_data = ads_res.data
            
            if not prod_data or not ads_data:
                return {
                    'success': True,
                    'data': {
                        'products': [],
                        'ads': [],
                        'stats': {'avg_score': 0, 'coverage': f"{len(prod_data or [])}/{len(ads_data or [])}"}
                    }
                }

            # Combine and parse embeddings for PCA
            all_embeddings = []
            valid_prods = []
            valid_ads = []

            for p in prod_data:
                emb = self._parse_embedding(p['embedding'])
                if emb:
                    all_embeddings.append(emb)
                    valid_prods.append(p)
            
            for a in ads_data:
                emb = self._parse_embedding(a['embedding'])
                if emb:
                    all_embeddings.append(emb)
                    valid_ads.append(a)

            if not all_embeddings:
                return {'success': False, 'error': 'No valid embeddings found after parsing.'}
            
            # Dimensionality Reduction
            X = np.array(all_embeddings)
            pca = PCA(n_components=2)
            coords = pca.fit_transform(X)
            
            # Split back to products and ads
            prod_points = []
            for i in range(len(valid_prods)):
                prod_points.append({
                    'x': float(coords[i, 0]),
                    'y': float(coords[i, 1]),
                    'label': valid_prods[i][prod_config['text_col']],
                    'type': 'product'
                })
                
            offset = len(valid_prods)
            ads_points = []
            for i in range(len(valid_ads)):
                ads_points.append({
                    'x': float(coords[offset + i, 0]),
                    'y': float(coords[offset + i, 1]),
                    'label': valid_ads[i][ads_config['text_col']],
                    'type': 'ads'
                })
                
            return {
                'success': True,
                'data': {
                    'products': prod_points,
                    'ads': ads_points,
                    'stats': {
                        'avg_score': 85, # Placeholder
                        'coverage': f"{len(valid_prods)}/{len(valid_ads)}"
                    }
                }
            }
        except Exception as e:
            print(f"Error in get_market_matching_data: {e}")
            return {'success': False, 'error': str(e)}

    def analyze_semantic_clusters(self, source_key, n_clusters=5):
        """Perform PCA and K-means clustering on the specified source."""
        # Map source to table and column config
        config = self.config_map.get(source_key)
        if not config:
            print(f"Error: Unknown source {source_key}")
            return None

        data = SemanticService.get_embeddings_from_table(config['table'], config['text_col'])
        if not data or len(data) < n_clusters:
            print(f"Error: Not enough data for clustering (found {len(data) if data else 0}, need {n_clusters})")
            return None

        # Prepare data for sklearn
        texts = [item[config['text_col']] for item in data]
        # Ensure embeddings are lists of floats
        embeddings = []
        for item in data:
            emb = item['embedding']
            if isinstance(emb, str):
                import json
                # Handle postgres vector format {1,2,3} -> [1,2,3]
                clean_emb = emb.replace('{', '[').replace('}', ']')
                try:
                    emb = json.loads(clean_emb)
                except Exception as e:
                    print(f"Error parsing embedding string: {e}")
                    continue
            embeddings.append(emb)
        
        if not embeddings:
            return None
            
        X = np.array(embeddings)

        # 1. K-means Clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        cluster_labels = kmeans.fit_predict(X)

        # 2. PCA for 2D Visualization
        pca = PCA(n_components=2)
        X_2d = pca.fit_transform(X)

        # Combine results
        results = []
        for i in range(len(texts)):
            results.append({
                'term': texts[i],
                'x': float(X_2d[i, 0]),
                'y': float(X_2d[i, 1]),
                'cluster': int(cluster_labels[i])
            })

        # Calculate cluster summaries
        clusters_summary = []
        for c in range(n_clusters):
            cluster_texts = [results[i]['term'] for i in range(len(results)) if results[i]['cluster'] == c]
            clusters_summary.append({
                'cluster_id': c,
                'count': len(cluster_texts),
                'examples': cluster_texts[:10]
            })

        return {
            'points': results,
            'summaries': clusters_summary
        }

    def get_ai_insights(self):
        """
        Analyze gaps between products and search terms, then call DashScope for insights.
        """
        try:
            # 1. Get current matching data
            match_data = self.get_market_matching_data()
            if not match_data['success']:
                return match_data

            prods = match_data['data']['products']
            ads = match_data['data']['ads']

            if not prods or not ads:
                return {'success': False, 'error': 'Not enough data for AI analysis.'}

            # 2. Identify "Gaps" (Search terms far from any product)
            # We'll use a simple distance threshold in the PCA 2D space for now
            gaps = []
            for ad in ads:
                min_dist = min([np.sqrt((ad['x'] - p['x'])**2 + (ad['y'] - p['y'])**2) for p in prods])
                if min_dist > 0.5: # Arbitrary threshold for "far" in PCA space
                    gaps.append(ad['label'])

            # Limit to top 20 gaps to avoid prompt length issues
            top_gaps = gaps[:20]
            
            # 3. Prepare AI Prompt
            import os
            import requests
            api_key = os.getenv("DASHSCOPE_API_KEY") or "sk-31935adea80c4d03bd0709155f11b2c0"
            
            product_names = [p['label'] for p in prods[:10]]
            
            prompt = f"""
            你是一个资深的无人机全球贸易专家。
            目前我们的产品库包含以下产品：{', '.join(product_names)}。
            
            然而，我们在 Google Ads 搜索数据中发现了一些“市场空白区”（即用户正在搜索，但我们的产品匹配度较低的词）：
            {', '.join(top_gaps)}。
            
            请基于以上数据，给出深度的市场洞察报告。报告应包含以下三个部分（请使用 Markdown 格式）：
            1. **商机发现 (Gap Analysis)**：分析这些搜索词代表了什么样的市场趋势。
            2. **产品研发建议 (R&D Suggestions)**：我们应该增加什么功能或产品来填补这些空白。
            3. **文案优化建议 (Copywriting)**：如何调整现有的营销话术以更好地捕获这些流量。
            
            请用专业、犀利、商业化的口吻撰写，多用行业术语（如“载重”、“航时”、“载荷”、“行业应用”等）。
            """

            # 4. Call DashScope
            response = requests.post(
                "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "qwen-turbo",
                    "input": {
                        "messages": [
                            { "role": "system", "content": "你是一个专业的商业分析师和无人机行业专家。" },
                            { "role": "user", "content": prompt }
                        ]
                    },
                    "parameters": { "result_format": "message" }
                }
            )
            
            res_json = response.json()
            if 'output' in res_json and 'choices' in res_json['output']:
                ai_content = res_json['output']['choices'][0]['message']['content']
                return {
                    'success': True,
                    'data': {
                        'insights': ai_content,
                        'gap_count': len(gaps)
                    }
                }
            else:
                return {'success': False, 'error': f"AI Service Error: {res_json}"}

        except Exception as e:
            print(f"Error in get_ai_insights: {e}")
            return {'success': False, 'error': str(e)}
