from flask import request, current_app, abort
from functools import wraps

def admin_required():
    """
    Check if the request is authorized via ADMIN_ACCESS_KEY.
    Can be used as a before_request handler or a decorator.
    """
    # Allow if in development environment
    if current_app.config.get("ENV") != "production":
        return

    admin_key = current_app.config.get("ADMIN_ACCESS_KEY")
    if not admin_key:
        # If no key configured, disable access entirely in prod for safety
        abort(403, "Admin tools disabled: ADMIN_ACCESS_KEY not configured.")
        
    # Check query param or header
    request_key = request.args.get("key") or request.headers.get("X-Admin-Key")
    
    if request_key != admin_key:
        abort(403, "Access Denied: Invalid Admin Key.")

def admin_only(f):
    """
    Decorator for specific routes that require admin access.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        admin_required()
        return f(*args, **kwargs)
    return decorated_function
