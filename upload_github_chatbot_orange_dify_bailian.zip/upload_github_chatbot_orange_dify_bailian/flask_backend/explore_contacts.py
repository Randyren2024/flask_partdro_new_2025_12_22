import os
import sys
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from supabase import create_client
from config import Config

def explore_table():
    print("Checking chat_contacts table structure and data...")
    try:
        # Manually initialize supabase client
        url = os.environ.get("SUPABASE_URL") or Config.SUPABASE_URL
        key = os.environ.get("SUPABASE_KEY") or Config.SUPABASE_KEY
        
        if not url or not key:
            print("Error: SUPABASE_URL or SUPABASE_KEY not found in environment or config.")
            return

        client = create_client(url, key)
        
        # Fetch multiple records to see diversity
        response = client.table('chat_contacts').select('*').limit(10).execute()
        if response.data:
            print(f"Found {len(response.data)} records.")
            for i, rec in enumerate(response.data):
                print(f"\nRecord {i+1}:")
                print(rec)
        else:
            print("Table is empty, fetching column info via RPC or other means is not directly supported by basic select.")
            # Try to get columns by selecting with a non-existent ID to get error or metadata if possible
            # But usually we can just check the code where it's defined or inserted
            print("No data found in chat_contacts.")
            
    except Exception as e:
        print(f"Error exploring table: {e}")

if __name__ == "__main__":
    explore_table()
