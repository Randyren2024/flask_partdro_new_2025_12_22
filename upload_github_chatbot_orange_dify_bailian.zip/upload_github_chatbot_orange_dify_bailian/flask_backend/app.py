from partdro import create_app

app = create_app()

if __name__ == "__main__":
    import os
    port_env = os.getenv("PORT", "5002")
    port = int(port_env) if port_env and port_env.isdigit() else 5002
    print(f"Server starting on port {port}")
    app.run(host='0.0.0.0', port=port, debug=True)
