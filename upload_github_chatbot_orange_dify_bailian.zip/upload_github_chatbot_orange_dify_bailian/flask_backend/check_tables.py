import os
from supabase import create_client
from config import Config

def list_tables():
    url = Config.SUPABASE_URL
    key = Config.SUPABASE_KEY
    supabase = create_client(url, key)
    
    # In Supabase Python client, there isn't a direct list_tables() in the REST API.
    # However, we can try to query the 'product' table directly to see if it exists.
    try:
        res = supabase.table('product').select('id').limit(1).execute()
        print("Success: 'product' table exists.")
    except Exception as e:
        print(f"Error: 'product' table might not exist or: {e}")

    try:
        res = supabase.table('products').select('id').limit(1).execute()
        print("Success: 'products' table exists.")
    except Exception as e:
        print(f"Error: 'products' table might not exist or: {e}")

if __name__ == "__main__":
    list_tables()
