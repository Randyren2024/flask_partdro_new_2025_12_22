import os
import requests
from config import Config

def get_categories():
    url = f"{Config.SUPABASE_URL}/rest/v1/category?select=id,name"
    headers = {
        "apikey": Config.SUPABASE_KEY,
        "Authorization": f"Bearer {Config.SUPABASE_KEY}",
    }
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            print(response.json())
        else:
            print(f"Error: {response.status_code}")
    except Exception as e:
        print(f"Exception: {e}")

if __name__ == "__main__":
    get_categories()
