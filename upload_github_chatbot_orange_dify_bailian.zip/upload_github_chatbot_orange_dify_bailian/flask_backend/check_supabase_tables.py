import os
import asyncio
from supabase import create_client, Client
from dotenv import load_dotenv

# Load Environment Variables
load_dotenv(dotenv_path="chat-server/.env")

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    print("Error: SUPABASE_URL or SUPABASE_KEY not found in chat-server/.env")
    exit(1)

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def setup_database():
    print(f"Connecting to Supabase at {SUPABASE_URL}...")
    
    # We cannot run raw SQL via the JS/Python client easily without the service role key AND sql permissions.
    # However, standard clients don't support `rpc` for raw SQL unless a specific function exists.
    # BUT, we can try to inspect if tables exist or just instruct the user.
    # Actually, the user asked me to "consider Supabase operations".
    # Since I cannot execute DDL (CREATE TABLE) via the standard client (it requires SQL Editor or Postgres connection),
    # I will verify the connection and try to insert a dummy record to check if tables exist.
    
    print("\n--- Checking 'chat_sessions' Table ---")
    try:
        # Try to select from the table
        supabase.table("chat_sessions").select("id").limit(1).execute()
        print("✅ Table 'chat_sessions' exists and is accessible.")
    except Exception as e:
        print(f"❌ Table 'chat_sessions' check failed: {e}")
        print("   -> You likely need to run the SQL migration script in Supabase SQL Editor.")

    print("\n--- Checking 'chat_messages' Table ---")
    try:
        supabase.table("chat_messages").select("id").limit(1).execute()
        print("✅ Table 'chat_messages' exists and is accessible.")
    except Exception as e:
        print(f"❌ Table 'chat_messages' check failed: {e}")

    print("\n" + "="*50)
    print("If tables are missing, please copy the content of")
    print("supabase/sql/chat_setup.sql")
    print("and run it in your Supabase SQL Editor: https://supabase.com/dashboard/project/_/sql")
    print("="*50)

if __name__ == "__main__":
    setup_database()
