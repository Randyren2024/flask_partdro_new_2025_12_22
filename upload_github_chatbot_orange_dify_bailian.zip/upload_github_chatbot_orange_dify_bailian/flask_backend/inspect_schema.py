import os
import requests
from config import Config

def get_table_schema(table_name):
    url = f"{Config.SUPABASE_URL}/rest/v1/"
    headers = {
        "apikey": Config.SUPABASE_KEY,
        "Authorization": f"Bearer {Config.SUPABASE_KEY}",
        "Accept": "application/openapi+json"
    }
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            schema = response.json()
            definitions = schema.get('definitions', {})
            product_def = definitions.get(table_name, {})
            properties = product_def.get('properties', {})
            required = product_def.get('required', [])
            
            print(f"Table: {table_name}")
            print("-" * 30)
            for col, props in properties.items():
                is_required = col in required
                col_type = props.get('type')
                description = props.get('description', '')
                print(f"{col:20} | {col_type:10} | {'REQUIRED' if is_required else 'OPTIONAL'} | {description}")
        else:
            print(f"Error fetching schema: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Exception: {e}")

if __name__ == "__main__":
    get_table_schema('product')
