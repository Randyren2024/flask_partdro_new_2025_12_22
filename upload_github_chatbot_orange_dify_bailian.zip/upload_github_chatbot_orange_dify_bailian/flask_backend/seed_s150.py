
import os
from supabase import create_client, Client
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

url = os.environ.get("SUPABASE_URL")
key = os.environ.get("SUPABASE_KEY") or os.environ.get("SUPABASE_SERVICE_ROLE_KEY") or os.environ.get("SUPABASE_ANON_KEY")

if not url or not key:
    raise ValueError("Supabase URL or Key not found in environment variables")

supabase: Client = create_client(url, key)

# S150 产品数据
product_data = {
    "product_id_no": "s150",
    "category_id": 2,  # 假设 2 是 Cargo Drones，或者根据实际情况调整
    "model": "S150",
    "name": "S150 Heavy Lift Drone",
    "description": "The S150 is a heavy-lift autonomous drone designed for logistics and industrial transport, featuring a 150kg payload capacity.",
    "landing_page": "s150_landing_page.html",
    "thumbnail": "https://cdncn.prodrone-tech.com/portal/20240626/63dc3d356ee7139ba067ce24de7e0f35.jpg-watermark",
    "name_en": "S150 Heavy Lift Drone",
    "description_en": "The S150 is a heavy-lift autonomous drone designed for logistics and industrial transport, featuring a 150kg payload capacity.",
    "name_ja": "S150 重量級ドローン",
    "description_ja": "S150は、物流および産業輸送用に設計された重量級自律型ドローンで、150kgの積載能力を備えています。",
    "name_es": "Dron de Carga Pesada S150",
    "description_es": "El S150 es un dron autónomo de carga pesada diseñado para logística y transporte industrial, con una capacidad de carga útil de 150 kg."
}

try:
    # 使用 upsert 插入或更新数据
    response = supabase.table("product").upsert(product_data, on_conflict="product_id_no").execute()
    print("Successfully inserted/updated S150 product data:")
    print(response.data)
except Exception as e:
    print(f"Error inserting data: {e}")
