import os
import sys
import json
import requests
import time
from supabase import create_client
from config import Config

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Configuration
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY") or "sk-31935adea80c4d03bd0709155f11b2c0"
EMBEDDING_MODEL = "text-embedding-v3" # 1024 dimensions to match vector(1024)

def get_embedding(text):
    """Call DashScope API to get embedding for text."""
    # Correct URL for DashScope native API
    url = "https://dashscope.aliyuncs.com/api/v1/services/embeddings/text-embedding/text-embedding"
    headers = {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": EMBEDDING_MODEL,
        "input": {
            "texts": [text]
        },
        "parameters": {
            "text_type": "document"
        }
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            result = response.json()
            return result["output"]["embeddings"][0]["embedding"]
        else:
            print(f"Error calling DashScope: {response.text}")
            return None
    except Exception as e:
        print(f"Exception calling DashScope: {e}")
        return None

def process_table(supabase, table_name, text_generator):
    print(f"Fetching {table_name} without embeddings...")
    try:
        response = supabase.table(table_name).select('*').is_('embedding', 'null').execute()
        items = response.data
        
        if not items:
            print(f"No {table_name} found without embeddings.")
            return

        print(f"Found {len(items)} items in {table_name} to process.")

        for item in items:
            item_id = item['id']
            descriptive_text = text_generator(item)
            print(f"Processing {table_name} ID {item_id}: {descriptive_text[:50]}...")
            
            embedding = get_embedding(descriptive_text)
            
            if embedding:
                try:
                    update_res = supabase.table(table_name).update({'embedding': embedding}).eq('id', item_id).execute()
                    if update_res.data:
                        print(f"Successfully updated ID {item_id}")
                    else:
                        print(f"WARNING: Update returned no data for ID {item_id}. Row might not exist or RLS issue.")
                except Exception as e:
                    print(f"Error updating Supabase for ID {item_id}: {e}")
            else:
                print(f"Failed to get embedding for ID {item_id}")
            
            time.sleep(0.5)
    except Exception as e:
        print(f"Error processing {table_name}: {e}")

def contact_text_gen(contact):
    name = contact.get('name') or "Unknown"
    country = contact.get('country') or "Unknown"
    email = contact.get('email') or "N/A"
    return f"Contact Name: {name}, Country: {country}, Email: {email}"

def analysis_text_gen(analysis):
    summary = analysis.get('summary') or ""
    intent = analysis.get('intent') or ""
    sentiment = analysis.get('sentiment') or ""
    return f"Summary: {summary}, Intent: {intent}, Sentiment: {sentiment}"

def message_text_gen(message):
    role = message.get('role') or "user"
    content = message.get('content') or ""
    return f"Role: {role}, Message: {content}"

def partner_text_gen(partner):
    name = partner.get('name') or ""
    company = partner.get('company') or ""
    industries = ", ".join(partner.get('industries') or [])
    message = partner.get('message') or ""
    return f"Partner: {name}, Company: {company}, Industries: {industries}, Message: {message}"

def product_text_gen(product):
    """
    Generate text for embedding from product fields.
    """
    name = product.get('name') or ""
    desc = product.get('description') or ""
    # Add other relevant fields if they exist in your schema
    return f"Product: {name}. Description: {desc}"

def search_term_text_gen(term):
    """
    Generate text for embedding from search term.
    """
    return term.get('search_term') or ""

def run_all():
    print("Initializing Supabase client...")
    url = Config.SUPABASE_URL
    key = Config.SUPABASE_KEY
    print(f"URL: {url}")
    print(f"Key Prefix: {key[:15]}...")
    supabase = create_client(url, key)

    print("\n--- Processing Chat Contacts ---")
    process_table(supabase, 'chat_contacts', contact_text_gen)
    
    print("\n--- Processing Chat Analysis ---")
    process_table(supabase, 'chat_analysis', analysis_text_gen)

    print("\n--- Processing Chat Messages ---")
    process_table(supabase, 'chat_messages', message_text_gen)

    print("\n--- Processing Partner Applications ---")
    process_table(supabase, 'partner_applications', partner_text_gen)

    print("\n--- Processing Product ---")
    process_table(supabase, 'product', product_text_gen)

    print("\n--- Processing Search Term Embeddings ---")
    process_table(supabase, 'search_term_embeddings', search_term_text_gen)

if __name__ == "__main__":
    run_all()
