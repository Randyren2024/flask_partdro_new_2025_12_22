# Babel 多语资源维护说明

## 目录结构
- 配置: [flask_backend/babel.cfg](file:///c:/Users/81102/Desktop/chatbot_orange_dify_bailian/flask_backend/babel.cfg)
- 翻译目录: `flask_backend/translations/`
  - 语言包: `zh_CN/LC_MESSAGES/messages.po`, `en/LC_MESSAGES/messages.po`
  - 编译后: `messages.mo`

## 提取模板字符串
1. 进入项目根目录
2. 运行:
   - `pybabel extract -F flask_backend/babel.cfg -o flask_backend/messages.pot flask_backend`

## 初始化语言包（首次）
- 中文: `pybabel init -i flask_backend/messages.pot -d flask_backend/translations -l zh_CN`
- 英文: `pybabel init -i flask_backend/messages.pot -d flask_backend/translations -l en`

## 更新语言包（新增或变更文案）
- `pybabel update -i flask_backend/messages.pot -d flask_backend/translations`

## 编译语言包
- `pybabel compile -d flask_backend/translations`

## 使用说明
- 模板中用 `_(\"...\")` 包裹文本
- JS 侧通过模板注入 `window.I18N = {...}`，读取已翻译的文案
- 语言选择：`?locale=`、cookie `lang` 或浏览器 `Accept-Language`

## 常见问题
- 若 `_(...)` 未生效，请确认 `flask_backend/config.py` 中 `BABEL_TRANSLATION_DIRECTORIES` 默认值为 `translations` 并且 `.mo` 文件已编译。
- 若语言切换无效，检查 `extensions.py` 的 `locale_selector` 是否正确解析 query/cookie。

