import requests
import json

# Configuration
FLASK_URL = "http://127.0.0.1:5000/analysis/trigger"

session_id = input("Enter Session ID to analyze: ").strip()
if not session_id:
    print("❌ Error: Session ID is required.")
    exit(1)

payload = {
    "session_id": session_id
}

print(f"\n🚀 Triggering Python-Native Analysis for session: {session_id}...")
try:
    # Bypass proxies to avoid "malformed url" errors on localhost
    response = requests.post(FLASK_URL, json=payload, proxies={"http": None, "https": None})
    print(f"Status Code: {response.status_code}")
    print("Response:")
    try:
        print(json.dumps(response.json(), indent=2, ensure_ascii=False))
    except:
        print(response.text)
except Exception as e:
    print(f"❌ Failed to trigger analysis: {e}")
