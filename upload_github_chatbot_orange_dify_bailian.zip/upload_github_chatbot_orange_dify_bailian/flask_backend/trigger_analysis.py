import os
import requests
import json
from dotenv import load_dotenv

# Load Env
load_dotenv(dotenv_path="chat-server/.env")

# Configuration
# If you deploy to Supabase, this URL will be: https://<project-ref>.supabase.co/functions/v1/analyze-chats
# You can find this in your Supabase Dashboard -> Edge Functions.
EDGE_FUNCTION_URL = "YOUR_SUPABASE_FUNCTION_URL_HERE" 

# Or if running locally via Supabase CLI:
# EDGE_FUNCTION_URL = "http://localhost:54321/functions/v1/analyze-chats"

# Since we don't have the URL yet, I'll ask the user to input it.
print("="*50)
print("Chat Analysis Trigger Tool")
print("="*50)

url = input(f"Enter Edge Function URL (default: {EDGE_FUNCTION_URL}): ").strip()
if not url:
    url = EDGE_FUNCTION_URL

if "YOUR_SUPABASE" in url:
    print("❌ Error: You must provide a valid Edge Function URL.")
    print("1. Deploy function: supabase functions deploy analyze-chats")
    print("2. Get URL from Dashboard")
    exit(1)

session_id = input("Enter Session ID to analyze (leave empty to analyze a recent one if possible, or provide specific): ").strip()
if not session_id:
    print("❌ Error: Session ID is required for now.")
    exit(1)

# Authorization
# Edge Functions usually require the ANON key or SERVICE_ROLE key in Authorization header
anon_key = os.getenv("SUPABASE_KEY")
if not anon_key:
    print("❌ Error: SUPABASE_KEY (anon key) not found in .env")
    exit(1)

headers = {
    "Authorization": f"Bearer {anon_key}",
    "Content-Type": "application/json"
}

payload = {
    "session_id": session_id
}

print(f"\n🚀 Triggering analysis for session: {session_id}...")
try:
    response = requests.post(url, json=payload, headers=headers)
    print(f"Status Code: {response.status_code}")
    print("Response:")
    try:
        print(json.dumps(response.json(), indent=2, ensure_ascii=False))
    except:
        print(response.text)
except Exception as e:
    print(f"❌ Failed to trigger function: {e}")
